# African Merit Report — AMR

Première version du site institutionnel AMR.

## Fichiers
- `index.html` : structure du site
- `style.css` : design responsive
- `app.js` : interactions du menu et formulaire de démonstration

## Mise en ligne avec GitHub Pages
Dans le dépôt GitHub :
**Settings → Pages → Build and deployment → Deploy from a branch → main → /(root) → Save**

Le formulaire newsletter présent dans cette version est une démonstration front-end : il faudra connecter un véritable service d'inscription avant utilisation en production.
