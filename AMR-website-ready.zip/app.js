const menu=document.querySelector('.menu'),nav=document.querySelector('#nav');
menu?.addEventListener('click',()=>nav.classList.toggle('open'));
document.querySelectorAll('nav a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
document.querySelector('#year').textContent=new Date().getFullYear();
function subscribe(e){e.preventDefault();const email=document.querySelector('#email').value;document.querySelector('#msg').textContent='Merci. '+email+' est bien enregistré pour la newsletter AMR.';e.target.reset();return false;}
